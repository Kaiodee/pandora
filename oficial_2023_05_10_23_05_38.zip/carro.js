let xCarro= [600,600,600,600,600,600]
let yCarro= [40,96,150,212,263,318]
let velocidadeDosCarros=[10,8,5,4,3,2]
let comprimentoDoCarro=50
let alturaDoCarro=40
let colisao= false 

function mostrarCarro(){
  for(let i=0; i<imagemDosCarros.length; i++ ){
image(imagemDosCarros[i],xCarro[i],yCarro[i],comprimentoDoCarro,alturaDoCarro)
  }
}
function movimentaCarro(){
  for(let i=0; i<imagemDosCarros.length; i++)
  xCarro[i]-=velocidadeDosCarros[i]
  
}
//function voltaPosiçãoInicialCarro(){
 // for (let i=0; i<imagemDosCarros.length; i++)
  
   // if(voltaPosiçãoInicial(xCarro[i])){
  //  xCarro[i]=600
  //}

//}
//function voltaPosiçãoInicial(xCarro){
 //return xCarro<-50
//}
function voltaPosiçãoInicialCarro(){
  for (let i=0; i<imagemDosCarros.length; i++)
  
    if(xCarro[i]<-50){
      xCarro[i]=600
    }
}

function colisaoComCarro(){
  for(let i=0; i<imagemDosCarros.length; i++){
 colisao = collideRectCircle(xCarro[i], yCarro[i],comprimentoDoCarro,alturaDoCarro,xAtor, yAtor, 15)
  
  if(colisao){
    yAtor=366;
    somDaColisao.play()
  
    if(pontos>0){
      pontos-=1;
    }
      
    
  }
  
  }

}


