let imagemDoAtor
let imagemDaEstrada
let imagemDoCarro
let imagemDoCarro2
let imagemDoCarro3
let imagemDoCarro4
let imagemDoCarro5
let imagemDoCarro6

let somDaColisao
let somDaTrilha
let somDosPontos

function preload(){
  imagemDaEstrada=loadImage("imagens/estrada.png")
  imagemDoAtor=loadImage("imagens/ator-1.png")
  imagemDoCarro=loadImage("imagens/carro-1.png")
  imagemDoCarro2=loadImage("imagens/carro-2.png")
  imagemDoCarro3=loadImage("imagens/carro-3.png")
  imagemDoCarro4=loadImage("imagens/carro-3.png")
  imagemDoCarro5=loadImage("imagens/carro-2.png")
  imagemDoCarro6=loadImage("imagens/carro-1.png")
  imagemDosCarros=[imagemDoCarro,imagemDoCarro2,imagemDoCarro3,imagemDoCarro4,imagemDoCarro5,imagemDoCarro6]
  
  somDaColisao= loadSound("sons/colidiu.mp3")
  somDosPontos= loadSound("sons/pontos.wav")
  somDaTrilha= loadSound("sons/trilha.mp3")
  
}

