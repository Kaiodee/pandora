function setup() {
  createCanvas(500, 400);
  somDaTrilha.loop();
}

function draw() {
  background(imagemDaEstrada);
   mostrarCarro()
 movimentaCarro()
voltaPosiçãoInicialCarro()
 // voltaPosiçãoInicial()
mostraAtor()
 movimentaAtor()
colisaoComCarro()
  Ponto()
  marcarPonto()



}