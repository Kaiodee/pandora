let xAtor= 100
let yAtor=366
let pontos=0;


function mostraAtor(){
  image(imagemDoAtor,xAtor,yAtor,30,30)
}

function movimentaAtor(){
  if(keyIsDown(UP_ARROW)){
    yAtor-=2
  }
  if(keyIsDown(DOWN_ARROW)){
    yAtor+=2
  }
}

function marcarPonto(){
  if(yAtor<15){
    pontos+=1
    somDosPontos.play()
  }
  if(yAtor<15){
    yAtor=366
    //ou voltaParaPosiçãoInicial()
  }
}



function Ponto(){
  text(pontos,width/5,27)
 fill(color(75,0,130))
  textAlign(CENTER)
  textSize(21)
  
 
  
}
